/*
        吕睿 22301050204
*/
#include<stdio.h>
int main(){
        int l,h,s;
        scanf("%d %d", &l,&h);
        s = l * h / 2;
        printf("%d",s);
        return 0;
}