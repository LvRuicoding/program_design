/*
        吕睿 22301050204
*/
#include<stdio.h>
int main(){
        float a,b;
        scanf("%f",&a);
        b = 5.0 / 9.0 * (a - 32);
        printf("%.2f",b);
        return 0;
}