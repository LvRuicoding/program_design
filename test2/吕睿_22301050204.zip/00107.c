/*
    吕睿 22301050204    
*/
#include<stdio.h>
int main(){
        float a;
        scanf("%f",&a);
        if(a >= 0) printf("%.3f",a);
        else printf("%.3f",-a);
        return 0;
}